import socket

deviceName = socket.gethostname()
clientIp = socket.gethostbyname(deviceName)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

serverIp = '127.0.0.1' 
port = 2020
serverSocketAdd = (serverIp, port)
initialBufferSize = 16

client.connect(serverSocketAdd)
print("Connecting to server...")

status = client.recv(128).decode("utf-8")
print(status)

def send_message(msg):
    message = msg.encode("utf-8")
    message_size = len(message)

    message_size_str = str(message_size).encode("utf-8")
    padding = b" " * (initialBufferSize - len(message_size_str)) 
    initial_message = message_size_str + padding
    client.send(initial_message) 

    client.send(message) 

    response = client.recv(128).decode("utf-8")
    print(f"Server response: {response}\n")


while True:
    data = input("Enter a sentence:\n")
    send_message(data)
    if data.lower() == "quit":
        break


send_message("Quit")

client.close()
