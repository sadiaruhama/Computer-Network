import socket
import threading

initialBufferSize = 16
port = 2020
deviceName = socket.gethostname()
serverIp = socket.gethostbyname(deviceName)

serverSocketAdd = (serverIp, port)
print(f"Server started at {serverSocketAdd}")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(serverSocketAdd)
server.listen()
print("Server starts listening...")

def count_vowels(message):
    vowels = "aeiouAEIOU"
    return sum(1 for char in message if char in vowels)


def handle_client(server_socket, client_address):
    print(f"Connected to {client_address}")

    server_socket.send("Connected".encode("utf-8"))

    connected = True
    while connected:
        upcoming_message_size = server_socket.recv(initialBufferSize).decode("utf-8")
        print(f"Upcoming message size: {upcoming_message_size}")
        
        if upcoming_message_size:
            message = server_socket.recv(int(upcoming_message_size)).decode("utf-8")
            print(f"Message from client: {message}")

            vowel_count = count_vowels(message)

            if vowel_count == 0:
                response = "Not enough vowels"
            elif vowel_count <= 2:
                response = "Enough vowels I guess"
            else:
                response = "Too many vowels"

            server_socket.send(response.encode("utf-8"))
            
            if message.lower() == "quit":
                connected = False
                server_socket.send("Disconnected".encode("utf-8"))
    
    server_socket.close()

while True:
    server_socket, client_address = server.accept()
    print(f"New connection from {client_address}")
    
  
    client_thread = threading.Thread(target=handle_client, args=(server_socket, client_address))
    client_thread.start()
