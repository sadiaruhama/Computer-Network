


import socket

initialBufferSize = 16
port = 2020
deviceName = socket.gethostname()
serverIp = socket.gethostbyname(deviceName)

serverSocketAdd = (serverIp, port)
print(f"Server started at {serverSocketAdd}")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(serverSocketAdd)

server.listen()
print("Server starts listening...")

while True:
    server_socket, client_address = server.accept()
    print(f"Connected to {client_address}")

    server_socket.send("Connected".encode("utf-8"))

    connected = True

    while connected:
        upcoming_message_size = server_socket.recv(initialBufferSize).decode("utf-8")
        print(f"Upcoming message size: {upcoming_message_size}") 
        
        if upcoming_message_size:
            message = server_socket.recv(int(upcoming_message_size)).decode("utf-8")
            print(f"Message from client: {message}")

            if message == "Quit":
                connected = False
                server_socket.send("Disconnected".encode("utf-8"))
                continue

           
            print(f"Client Info: {message}")
            server_socket.send("Message Received".encode("utf-8"))
    
    server_socket.close()
