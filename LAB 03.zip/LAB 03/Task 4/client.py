import socket


server_ip = '127.0.0.1' 
port = 2020
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


client_socket.connect((server_ip, port))
status = client_socket.recv(1024).decode("utf-8")
print(status)


hours_worked = input("Enter the number of hours worked: ")
client_socket.send(hours_worked.encode("utf-8"))
response = client_socket.recv(1024).decode("utf-8")
print(response)


client_socket.close()
