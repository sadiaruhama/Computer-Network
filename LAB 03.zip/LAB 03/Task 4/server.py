import socket

server_ip = '127.0.0.1' 
port = 2020
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((server_ip, port))
server_socket.listen(1) 

print(f"Server started at {server_ip}:{port}")
print("Waiting for a connection...")


client_socket, client_address = server_socket.accept()
print(f"Connection established with {client_address}")


client_socket.send("Connected to server".encode("utf-8"))


data = client_socket.recv(1024).decode("utf-8")


def calculate_salary(hours):
    if hours <= 40:
        salary = hours * 200  # Tk 200 per hour if hours are <= 40
    else:
        salary = 8000 + (hours - 40) * 300  # Tk 8000 + Tk 300 for each hour over 40
    return salary


data = data.strip()

if data.replace('.', '', 1).isdigit():
    hours_worked = float(data)
    salary = calculate_salary(hours_worked)
    response = f"Salary for {hours_worked} hours worked: Tk {salary}"
else:
    response = "Invalid input..."


client_socket.send(response.encode("utf-8"))


client_socket.close()
